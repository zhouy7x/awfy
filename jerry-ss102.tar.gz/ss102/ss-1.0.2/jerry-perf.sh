#!/bin/bash

# Author Chen Li
# Based on run-perf-test.sh

ENGINE="$1"
REPEATS="$2"
TIMEOUT="$3"
BENCH_FOLDER="$4"

function run-test()
{
  TEST=$1

  # print only filename
  printf "%40s | " "${TEST##*/}"

  # record performence and memory scores
  PERF=$(timeout "${TIMEOUT}" ./perf.sh "${REPEATS}" "${ENGINE}" "${TEST}") || return 1
  #MEM=$(timeout "${TIMEOUT}" setarch linux32 -R ./rss-measure.sh "${ENGINE}" "${TEST}") || return 1
  
  printf "$PERF\n"

  # save mem-stats files

  #printf "${ENGINE} --mem-stats ${TEST}"
  #TMPM=$("${ENGINE}" --mem-stats "${TEST}")
  #printf "$TMPM"
  # > "mem-tmp-${TEST##*/}.txt"
}

function run-suite()
{
  FOLDER=$1

  for BENCHMARK in ${FOLDER}/*.js
  do
    run-test "${BENCHMARK}" 2> /dev/null || printf "<FAILED>\n" "${BENCHMARK}";
  done
}

run-suite "${BENCH_FOLDER}"

#/build/bin/release.linux-mem_stats/jerry --mem-stats ../../benchmarks/JerrySs/3d-raytrace.js 
